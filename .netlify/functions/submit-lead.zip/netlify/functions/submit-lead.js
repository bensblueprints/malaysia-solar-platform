// netlify/functions/submit-lead.js
exports.handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  try {
    const data = JSON.parse(event.body);
    if (!data.name || !data.phone || !data.email) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Missing required fields: name, phone, email" })
      };
    }
    const webhookUrl = process.env.GHL_WEBHOOK_URL;
    if (!webhookUrl) {
      console.error("GHL_WEBHOOK_URL not configured");
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          message: "Lead received (webhook not configured)"
        })
      };
    }
    const ghlPayload = {
      // Contact fields
      firstName: data.name.split(" ")[0],
      lastName: data.name.split(" ").slice(1).join(" ") || "",
      email: data.email,
      phone: data.phone,
      address1: data.address || "",
      // Custom fields (configure in GHL)
      customField: {
        tnb_bill: data.tnb_bill,
        property_type: data.property_type,
        is_homeowner: data.is_homeowner,
        roof_size: data.roof_size,
        system_size: data.system_size,
        monthly_savings: data.monthly_savings,
        yearly_savings: data.yearly_savings,
        roi_years: data.roi_years,
        system_price: data.system_price
      },
      // Source tracking
      source: data.source || "Website Calculator",
      tags: ["Solar Lead", "Website", data.system_size || "Unknown System"],
      // Timestamp
      dateAdded: data.timestamp || (/* @__PURE__ */ new Date()).toISOString()
    };
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(ghlPayload)
    });
    if (!response.ok) {
      console.error("GHL webhook error:", response.status, await response.text());
    }
    console.log("Lead submitted:", {
      name: data.name,
      email: data.email,
      system_size: data.system_size,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: "Lead submitted successfully"
      })
    };
  } catch (error) {
    console.error("Error processing lead:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        message: error.message
      })
    };
  }
};
