// netlify/functions/process-payment.js
exports.handler = async (event, context) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  try {
    const data = JSON.parse(event.body);
    if (!data.name || !data.email || !data.amount) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Missing required fields" })
      };
    }
    console.log("Payment request received:", {
      name: data.name,
      email: data.email,
      amount: data.amount,
      systemSize: data.systemSize,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
    const ghlWebhook = process.env.GHL_PAYMENT_WEBHOOK_URL;
    if (ghlWebhook) {
      try {
        await fetch(ghlWebhook, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            type: "payment_intent",
            customer: data.name,
            email: data.email,
            amount: data.amount,
            system_size: data.systemSize,
            status: "pending_integration",
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        });
      } catch (webhookError) {
        console.error("Webhook notification failed:", webhookError);
      }
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: "Payment request received. Our team will contact you to complete the booking.",
        reference: `MS-${Date.now()}`
      })
    };
  } catch (error) {
    console.error("Error processing payment:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        message: "Payment processing failed. Please try again or contact support."
      })
    };
  }
};
